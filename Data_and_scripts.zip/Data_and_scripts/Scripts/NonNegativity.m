function [NonNeg, NonNegGlobal] = NonNegativity(spectra)
% ========================================================================
% MAKING SPECTRA NONNEGATIVE
%
% INPUT
%   - spectra = spectra to which min value of each column will be added to 
%     that column !! matrix without wavelenghts column
%   - NonNeg = Corrected spectra
% ========================================================================
NonNeg = spectra;
a = min(spectra);
for i=1:size(spectra,2),
    b = (-1)*a(i);
    NonNeg(:,i) = spectra(:,i) + b;
end

c = min(min(spectra,[],2));
c = (-1)*c;
for i=1:size(spectra,2),
	NonNegGlobal(:,i) = spectra(:,i) + c;
end;
	