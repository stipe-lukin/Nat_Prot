%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%          SCRIPT FOR BASIC ANALYSIS AND VISUALIZATION OF 
%                  IN SITU RAMAN MONITORING DATA  
%
%                       Author: Stipe Lukin
%                       Email: slukin@irb.hr
%
% If you use this script or find it usefull please cite:
% S.Lukin, K. Užarević, I. Halasz, Raman spectroscopy for real-time and 
% in situ monitoring of mechanochemical milling reactions, Nat. Protoc. 2020
%
% Copyright (c) 2020  Stipe Lukin
%
%Permission is hereby granted, free of charge, to any person obtaining a copy of this 
%software and associated documentation files (the "Software"), to deal in the Software 
%without restriction, including without limitation the rights to use, copy, modify, merge, 
%publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons 
%to whom the Software is furnished to do so, subject to the following conditions:
%
%The above copyright notice and this permission notice shall be included in all copies or 
%substantial portions of the Software.
%
%THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
%INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR 
%PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE 
%FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
%OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
%DEALINGS IN THE SOFTWARE.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%   DEFINE PATH TO WORKING DIRECTORY    %%%%%%%%%%%%%%%

% define path to the folder with the scripts:
% example addpath('C:/Users/jsmith/Desktop/Scripts');
addpath('replace-with-path-to-the-folder-with-the-scripts'); 

cwd = 'replace-with-path-to-the-folder-with-the-Raman-data';
cd(cwd);

%====================================================================


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%    CREATE A MATRIX OF RAMAN SPECTRA	%%%%%%%%%%%%%%

SpectraAll = [];
%DataStructure = dir(cwd);
DataStructure = dir(cwd);
DataStructure = DataStructure(~cellfun('isempty', {DataStructure.date}));
%
for ii = 1:size(DataStructure,1),
	if DataStructure(ii).isdir == 0,
		spectrum = importdata(DataStructure(ii).name);
		SpectraAll = cat(2,SpectraAll,spectrum(:,2));
	end
end
Wavenumbers = spectrum(:,1);

% Correct for cosmic spikes and faulty pixels:
SpectraAll = Cosmic(SpectraAll,195,535);
SpectraAll = Cosmic(SpectraAll,887,1011);
SpectraAll = Cosmic(SpectraAll,1230,1297);
clear spectrum ii 
%===============================================================



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% 	SUBTRACT THE RAMAN CONTRIBUTION OF THE JAR	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load the Jar spectrum: 
JarPath = 'replace-with-path-to-the-folder-with-the-Raman-data\Jar';
JarStructure = dir(JarPath);
cd(JarPath);
for ii=1:size(JarStructure,1),
	if JarStructure(ii).isdir == 0,
		Jar = importdata(JarStructure(ii).name);
	end
end

% Correct for cosmic spikes and faulty pixels:
Jar = Cosmic(Jar, 195,535);
Jar = Cosmic(Jar, 887,1297);
Jar = Cosmic(Jar, 1230,1861);

clear JarPath JarStructure ii 
cd(cwd);
% define the PMMA Raman peak:
first_point = 1492;
last_point = 1555;

Spectra = ones(size(SpectraAll,1),size(SpectraAll,2));
% in this loop you subtract the Raman contribution of the jar: 
for ii = 1:size(SpectraAll,2),
  
  jar_peak = Jar(first_point:last_point, 2);
  spectrum_for_sub = SpectraAll(first_point:last_point, ii);
    
  [jarCorr,~] = ALSbaseline(jar_peak,10000,0.0002,30);
  [spectrumCorr,~] = ALSbaseline(spectrum_for_sub,10000,0.0002,30);
  
  scale = jarCorr\spectrumCorr;
  jarscaled = Jar(:,2).*scale;
  Spectra(:,ii) = SpectraAll(:,ii) - jarscaled;
end
clear jar_peak spectrum_for_sub scale jarscaled jarCorr spectrumCorr baselinejarCorr baselinespectrumCorr
% after subtraction, new spectra are stored in variable Spectra

%=======================================================================================




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%    CREATE COLUM VECTOR OF TIMES    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

IntegrationTime = 1;  % IN SECONDS
Scans = 15;
Times = [Scans*IntegrationTime:Scans*IntegrationTime:(Scans*IntegrationTime)*size(Spectra,2)]'; % in seconds
Time = Times./60; % this changes it to minutes

%==========================================================================================================




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    DEFINE SPECTRAL AND TEMPORAL RANGE OF THE EXPERIMENT    %%%%%%%%%

first_wnmb = 90;
last_wnmb = 1650;
from_t0 = 1;
to_t = size(Spectra,2);
wn = Wavenumbers(first_wnmb:last_wnmb,:);


sp = Spectra(first_wnmb:last_wnmb,from_t0:to_t);

%=============================================================================




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%    BASELINE CORRECTION AND NORMALIZATION    %%%%%%%%%%%%%%%%%

[spCorr, als] = ALSbaseline(sp,10000,0.0001,30);
if min(min(spCorr)) < 0, 
	Nsp = NonNegativity(spCorr); clear spCorr 
end
% if exist, baseline-corrected spectra are stored now in variable Nsp, otherwise 
% they are stored in variable spCorr 
if ismatrix(Nsp),
	N1sp = Norm1(Nsp);
  else
	N1sp = Norm1(spCorr);
end
% normalized (L1 norm) spectra are stored in variable N1sp

%===============================================================================




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%    VISUALIZATION    %%%%%%%%%%%%%%%%%%%%%%%%%

%%
spectra = N1sp;
x1 = 120;
x2 = size(N1sp);
t1 = 1;
t2 = size(Time,1);

% 2D plot, first figure without phonone region
figure,
surface(Time(t1:t2,1), wn(x1:x2,1), spectra(x1:x2,t1:t2), 'FaceColor', 'interp','FaceLighting','gouraud','EdgeColor', 'none'),
colormap(jet(5000)),
shading interp; 
view(-90,90),
ylabel('Raman shift / cm^{-1}'), 
xlabel('Time / min');
axis tight
axgCp=gca;
set(axgCp,'FontName','Arial','FontSize',16,'TickDir','out','TickLength',[0.02 0.025],'XMinorTick','on','YMinorTick','on', 'color', 'b');

% second figure will plot only phonone part of the Raman spectra
spectra = N1sp;
x1 = 1;
x2 = 120;
t1 = 1;
t2 = size(Time,1);

% 2D plot, figure of phonone region
figure,
surface(Time(t1:t2,1), wn(x1:x2,1), spectra(x1:x2,t1:t2), 'FaceColor', 'interp','FaceLighting','gouraud'),
colormap(jet(5000)),
shading interp; 
view(-90,90),
ylabel('Raman shift / cm^{-1}'), 
xlabel('Time / min');
axis tight
axgCp=gca;
set(axgCp,'FontName','Arial','FontSize',16,'TickDir','out','TickLength',[0.02 0.025],'XMinorTick','on','YMinorTick','on','color', 'b');


%% Figure with reaction profile based on the single peak maxima
n=1;
figure, plot(Time(1:n:end,1),[N1sp(758,1:n:end);N1sp(531,1:n:end);N1sp(549,1:n:end)],'.','MarkerSize',15),
ylabel('Intensity / a.u.'), 
xlabel('Time / min');
axis tight
axgCpp=gca;
set(axgCpp,'FontName','Arial','FontSize',16,'TickDir','out','TickLength',[0.02 0.025],'XMinorTick','on','YMinorTick','off');



