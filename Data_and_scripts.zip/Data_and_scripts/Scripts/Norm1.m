function [Norm_1] = Norm1(Xsp)
% ========================================================================
% INPUT
%   - Xsp = spectra for normalizing
%   - Norm_1 = each spectrum divided by sum of abs intensities
%	Taxicab norm or Manhattan norm or L1 norm
% ========================================================================

Norm_1 = Xsp*diag(1./sum(abs(Xsp)));
 

