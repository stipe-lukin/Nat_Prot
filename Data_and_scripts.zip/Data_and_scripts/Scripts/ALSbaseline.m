function [XcALS, ALS] = ALSbaseline(Xals, als_lambda, als_p, als_itermax)
% Asymmetric Least Squares baseline correction
%   INPUT
%    X = ROW matrix of spectra - transpose the original data matrix for this use
%    lambda = smoothing factor 
%    p = asymmetry factor
%    itermax = max number of iterations (10 - 20)
%    typical value for p for positive peaks is 0.0001 <= p <= 0.01
%    typical value for lambda is 10E2 <= lambda <= 10E9
%
if nargin < 4
    als_itermax = 10;
  if nargin < 3
      als_p=0.001;
     if nargin < 2
        als_lambda = 10000;
         if nargin < 1
            error('ALSbaseline:NotEnoughInputs','Not enough input arguments. See ALSbaseline.m.');
         end
     end
  end
end
 Xals=Xals';
 [m, n]=size(Xals);
  D = diff(speye(n), 2);
  ALS = Xals;
 for i = 1:m,
  y= Xals(i,:);   
  w = ones(n, 1);
  for it = 1:als_itermax,
   W = spdiags(w, 0, n, n);
   C = chol(W + als_lambda * (D' * D));
   g = C \ (C' \ (w .* y'));
   w = als_p * (y' > g) + (1 - als_p) * (y' < g);
  end
 
  ALS(i,:)=g; % this is baseline estimation
 end
XcALS=Xals-ALS;
XcALS=XcALS';
ALS=ALS';
%figure,plot(XcALS); title('Spectra after ALS');
%figure,plot(ALS); title('ALS baselines');
%dlmwrite('XcALS_3_00005_30.txt',XcALS,'delimiter',' ','precision',5);
%dlmwrite('ALS_3_00005_30.txt',ALS,'delimiter',' ','precision',5);
