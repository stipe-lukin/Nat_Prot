function [SpCPS] = Cosmic(psr, a1, a2)
% ========================================================================
% COSMIC RAY SPIKE CORRECTION
%
% INPUT
%   - wnb = wavenuber for spike correction
%   - Smcean = spike corrected pure spectra
% ========================================================================
if nargin < 3
    b = 3;
    if nargin < 2
        error ('Cosmic:Error','Not enough input arguments')
    end
end 
a=a1;
b=a2;
psr(a ,:)=(psr(a-2,:)+psr(a-1,:)+psr(a+1,:)+psr(a+2,:))/4;
psr(b ,:)= (psr(b-2,:)+psr(b-1,:)+psr(b+1,:)+psr(b+2,:))/4;
SpCPS = psr;




