GNU Octave version 5.2.0 (available at https://www.gnu.org/software/octave/download.html)
RamanBoxx Control Panel v1.3 (comes with the instrument as standalone software)
OceanView v2.0 (available at https://www.oceaninsight.com/support/software-downloads/)

Data was tested on Windows 10 operating system.